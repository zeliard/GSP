// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <process.h>
#include <assert.h>
#include <limits.h>

#include <WinSock2.h>
#include <Mswsock.h>

#include <cstdint>
#include <memory>
#include <functional>

#include <ppl.h>
#include <concurrent_queue.h>

// TODO: reference additional headers your program requires here
