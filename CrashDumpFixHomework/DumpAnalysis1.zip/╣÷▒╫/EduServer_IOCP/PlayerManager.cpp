#include "stdafx.h"
#include "Player.h"
#include "PlayerManager.h"

PlayerManager* GPlayerManager = nullptr;

PlayerManager::PlayerManager() : mLock(LO_ECONOMLY_CLASS), mCurrentIssueId(0)
{
	//TODO: lock order ���⿡?
}

int PlayerManager::RegisterPlayer(std::shared_ptr<Player> player)
{
	FastSpinlockGuard exclusive(mLock);

	mPlayerMap[++mCurrentIssueId] = player;

	return mCurrentIssueId;
}

void PlayerManager::UnregisterPlayer(int playerId)
{
	FastSpinlockGuard exclusive(mLock);

	mPlayerMap.erase(playerId);
}

void PlayerManager::ListupCurrentPlayers()
{
	FastSpinlockGuard shared(mLock, false);

	printf_s("CURRENT PLAYER IDs: ");
	for (auto& it : mPlayerMap)
	{
		printf_s("%d, ", it.second->GetPlayerId());
	}

	printf_s("\n");

}

int PlayerManager::GetCurrentPlayers(PlayerList& outList)
{
	FastSpinlockGuard shared(mLock, false);

	int total = 0;

	for (const auto& it : mPlayerMap)
	{
		outList.push_back(it.second);

		++total;
	}

	return total;
}