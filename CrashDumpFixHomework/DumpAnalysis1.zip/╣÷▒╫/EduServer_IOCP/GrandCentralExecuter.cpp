#include "stdafx.h"
#include "GrandCentralExecuter.h"

GrandCentralExecuter* GGrandCentralExecuter = nullptr;
