﻿
IOCP Echo Server for educational purposes only.

# Student Homework 

8월 16일 토요일 자정까지: (약 2주)
(다음주는 휴강)

*IOCP를 사용하여 Dummy Client 구현. 
(다른 프로젝트로 분리, perf_client처럼 특정 시간동안 멀티 세션을 맺어서 send/recv 양 측정 가능하게, ConnectEx 사용)

*멀티스레드 관련 서버 구현
Timer, DoSync, LockOrder(TLS 사용), RWLock (FastSpinLock을 수정)
Simple lock-free dispatcher (GCE)

--todo
GCE 예제 구현  (file logging?)


시나리오
클라이언트 로그인 - 플레이어 스타트 (dosync)  - 주기적으로 printf (timer, dosync) 
현재 접속자 테스트 (R/W 사용 예제)



# 참고자료 (과제와 별개로 반드시 이해할 것)

https://github.com/zeliard/Dispatcher

