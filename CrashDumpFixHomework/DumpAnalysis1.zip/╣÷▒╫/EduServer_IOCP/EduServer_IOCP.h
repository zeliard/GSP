#pragma once

#define LISTEN_PORT		9001
#define MAX_CONNECTION	10000


