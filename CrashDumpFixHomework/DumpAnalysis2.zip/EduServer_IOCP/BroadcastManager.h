#pragma once
#include "XTL.h"
#include "FastSpinlock.h"

struct PacketHeader;
class ClientSession;

class BroadcastManager : public std::enable_shared_from_this<BroadcastManager>
{
public:
	BroadcastManager();
	virtual ~BroadcastManager() {}

	void RegisterClient(ClientSession* client);
	void UnregisterClient(ClientSession* client);

	void BroadcastPacket(PacketHeader* pkt);

private:
	FastSpinlock mLock;

	xset<ClientSession*>::type mConnectedClientSet;
	int mCurrentConnectedCount;

};

extern std::shared_ptr<BroadcastManager> GBroadcastManager;