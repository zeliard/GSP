// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <process.h>
#include <assert.h>
#include <limits.h>

#include <WinSock2.h>
#include <Mswsock.h>

#include <cstdint>
#include <memory>
#include <deque>
#include <vector>
#include <map>
#include <hash_map>
#include <set>
#include <hash_set>
#include <queue>
#include <type_traits>
#include <iostream>
#include <sstream>
#include <functional>

#include <ppl.h>
#include <concurrent_queue.h>
