#pragma once

#define MAX_NAME_LEN	32
#define MAX_COMMENT_LEN	256

#define HEART_BEAT 1000
